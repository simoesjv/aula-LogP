namespace Exercício_Idade
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int idade = int.Parse(textBox1.Text);
            int meses; 

            meses = idade * 12;

            MessageBox.Show("Idade em meses: " + meses);

        }
    }
}
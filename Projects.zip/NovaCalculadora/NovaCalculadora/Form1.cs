namespace NovaCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int numero1 = int.Parse(textBox1.Text);
            int numero2 = int.Parse(textBox2.Text);
            float resultado;
            //divis�o;
            resultado = numero1 / numero2;
            MessageBox.Show("divis�o: " + resultado);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void soma_Click(object sender, EventArgs e)
        {
          int numero1 = int.Parse(textBox1.Text);
            int numero2 = int.Parse(textBox2.Text);
            float resultado;
                //soma;
                resultado = numero1 + numero2;
            MessageBox.Show("soma: " + resultado);
        }

        private void subtracao_Click(object sender, EventArgs e)
        {
            int numero1 = int.Parse(textBox1.Text);
            int numero2 = int.Parse(textBox2.Text);
            float resultado;
            //subtra��o;
      
            resultado = numero1 - numero2;
            MessageBox.Show("subtra��o: " + resultado);
        }

        private void multiplicacao_Click(object sender, EventArgs e)
        {
            int numero1 = int.Parse(textBox1.Text);
            int numero2 = int.Parse(textBox2.Text);
            float resultado;
            //multiplica��o;
            resultado = numero1 * numero2;
            MessageBox.Show("multiplica��o: " + resultado);
        }
    }
}